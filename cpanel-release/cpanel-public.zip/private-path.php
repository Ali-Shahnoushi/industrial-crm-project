<?php
return '/home/CPANEL_USER/private_pro/project1/myc';
