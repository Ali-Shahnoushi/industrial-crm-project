<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Part extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'code',
        'periodic_service_months',
        'stock_quantity',
        'min_stock',
        'unit',
        'unit_price',
        'description',
        'is_active',
    ];

    protected $appends = [
        'is_low_stock',
    ];

    protected function casts(): array
    {
        return [
            'is_active' => 'boolean',
            'periodic_service_months' => 'integer',
            'stock_quantity' => 'integer',
            'min_stock' => 'integer',
            'unit_price' => 'integer',
        ];
    }

    public function getIsLowStockAttribute(): bool
    {
        if (!$this->is_active) {
            return false;
        }
        $min = (int) ($this->min_stock ?? 0);
        $stock = (int) ($this->stock_quantity ?? 0);

        return $min > 0 ? $stock <= $min : $stock <= 0;
    }

    public function customerParts(): HasMany
    {
        return $this->hasMany(CustomerPart::class);
    }

    public function inventoryLogs(): HasMany
    {
        return $this->hasMany(PartInventoryLog::class)->latest();
    }

    public function customers(): BelongsToMany
    {
        return $this->belongsToMany(Customer::class, 'customer_parts')
            ->withPivot([
                'id',
                'serial_number',
                'quantity',
                'invoice_amount',
                'invoice_number',
                'installation_date',
                'warranty_expire_date',
                'status',
                'notes',
            ])
            ->withTimestamps();
    }
}
