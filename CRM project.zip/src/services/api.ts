import axios from 'axios'
import type { ResourceName, Resources } from '../types'

/** `/api` is proxied to json-server (see vite.config.ts). */
export const http = axios.create({ baseURL: '/api' })

export const getAll = async <K extends ResourceName>(r: K) => (await http.get<Resources[K][]>(`/${r}`)).data
export const createOne = async <K extends ResourceName>(r: K, body: Partial<Resources[K]>) =>
  (await http.post<Resources[K]>(`/${r}`, body)).data
export const patchOne = async <K extends ResourceName>(r: K, id: string, body: Partial<Resources[K]>) =>
  (await http.patch<Resources[K]>(`/${r}/${id}`, body)).data
export const deleteOne = async (r: ResourceName, id: string) => {
  await http.delete(`/${r}/${id}`)
}
