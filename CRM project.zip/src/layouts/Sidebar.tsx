import { NavLink } from 'react-router-dom'
import { Sparkles, X } from 'lucide-react'
import { NAV } from './nav'
import { useList } from '../hooks/useData'
import { cx, num } from '../utils/format'

export function Logo({ size = 'md' }: { size?: 'md' | 'lg' }) {
  return (
    <div className="flex items-center gap-3">
      <span
        className={cx(
          'gradient-brand flex items-center justify-center rounded-2xl font-black text-white shadow-lg shadow-primary/30',
          size === 'lg' ? 'size-14 text-3xl' : 'size-10 text-xl',
        )}
      >
        ن
      </span>
      <div className="leading-tight">
        <p className={cx('font-extrabold', size === 'lg' ? 'text-2xl' : 'text-lg')}>نیکان</p>
        <p className="text-[11px] text-base-content/50">مدیریت ارتباط با مشتری</p>
      </div>
    </div>
  )
}

export function Sidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { data: rooms } = useList('rooms')
  const { data: tickets } = useList('tickets')
  const badges = {
    chat: rooms.reduce((s, r) => s + r.unread, 0),
    tickets: tickets.filter((t) => t.status === 'open').length,
  }

  return (
    <>
      {open && <div className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm lg:hidden" onClick={onClose} aria-hidden />}
      <aside
        className={cx(
          'fixed inset-y-0 right-0 z-50 flex w-72 flex-col border-l border-base-300/60 bg-base-100 transition-transform duration-300 lg:static lg:z-auto lg:translate-x-0',
          open ? 'translate-x-0' : 'translate-x-full',
        )}
        aria-label="منوی اصلی"
      >
        <div className="flex h-16 shrink-0 items-center justify-between px-5">
          <Logo />
          <button className="btn btn-ghost btn-sm btn-circle lg:hidden" onClick={onClose} aria-label="بستن منو">
            <X className="size-5" />
          </button>
        </div>

        <nav className="flex-1 space-y-5 overflow-y-auto px-3 py-4">
          {NAV.map((group) => (
            <div key={group.title}>
              <p className="mb-1.5 px-3 text-[11px] font-semibold tracking-wide text-base-content/40">{group.title}</p>
              <ul className="space-y-1">
                {group.items.map(({ to, label, icon: Icon, end, badge }) => (
                  <li key={to}>
                    <NavLink
                      to={to}
                      end={end}
                      onClick={onClose}
                      className={({ isActive }) =>
                        cx(
                          'group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all',
                          isActive
                            ? 'bg-primary text-primary-content shadow-md shadow-primary/30'
                            : 'text-base-content/70 hover:bg-base-200 hover:text-base-content',
                        )
                      }
                    >
                      <Icon className="size-5 shrink-0" />
                      <span className="flex-1">{label}</span>
                      {badge && badges[badge] > 0 && (
                        <span className="badge badge-sm badge-error border-0 text-white">{num(badges[badge])}</span>
                      )}
                    </NavLink>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>

        <div className="p-3">
          <div className="gradient-brand relative overflow-hidden rounded-2xl p-4 text-white">
            <Sparkles className="absolute -start-2 -top-2 size-16 opacity-15" />
            <p className="text-sm font-bold">نسخه نمایشی نیکان</p>
            <p className="mt-1 text-xs leading-5 text-white/80">تمام داده‌ها نمونه و ساختگی هستند.</p>
          </div>
        </div>
      </aside>
    </>
  )
}
