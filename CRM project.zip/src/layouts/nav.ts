import type { LucideIcon } from 'lucide-react'
import {
  BarChart3, Boxes, CalendarDays, Filter, LayoutDashboard, LifeBuoy, ListChecks, MessagesSquare, Receipt, Settings, Users,
} from 'lucide-react'

export interface NavItem {
  to: string
  label: string
  icon: LucideIcon
  end?: boolean
  badge?: 'chat' | 'tickets'
}
export interface NavGroup { title: string; items: NavItem[] }

export const NAV: NavGroup[] = [
  {
    title: 'اصلی',
    items: [{ to: '/', label: 'داشبورد', icon: LayoutDashboard, end: true }],
  },
  {
    title: 'مشتریان و فروش',
    items: [
      { to: '/customers', label: 'مشتریان', icon: Users },
      { to: '/pipeline', label: 'کاریز فروش', icon: Filter },
      { to: '/sales', label: 'فروش‌ها', icon: Receipt },
      { to: '/reports', label: 'گزارش و تحلیل', icon: BarChart3 },
    ],
  },
  {
    title: 'عملیات',
    items: [
      { to: '/inventory', label: 'انبار و موجودی', icon: Boxes },
      { to: '/tasks', label: 'وظایف', icon: ListChecks },
      { to: '/calendar', label: 'تقویم', icon: CalendarDays },
      { to: '/tickets', label: 'تیکت‌ها', icon: LifeBuoy, badge: 'tickets' },
    ],
  },
  {
    title: 'ارتباطات',
    items: [{ to: '/chat', label: 'گفتگو با همکاران', icon: MessagesSquare, badge: 'chat' }],
  },
  {
    title: 'سیستم',
    items: [{ to: '/settings', label: 'تنظیمات', icon: Settings }],
  },
]
