import { Suspense, useState } from 'react'
import { Navigate, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { LogOut, Menu, Moon, Settings, Sun, User } from 'lucide-react'
import toast from 'react-hot-toast'
import { Sidebar } from './Sidebar'
import { GlobalSearch } from './GlobalSearch'
import { NotificationsMenu } from './NotificationsMenu'
import { Avatar } from '../components/ui/Avatar'
import { PageSkeleton } from '../components/ui/Field'
import { useAuthStore } from '../store/useAuthStore'
import { useThemeStore } from '../store/useThemeStore'
import { roleLabel } from '../utils/meta'

const closeDropdown = () => (document.activeElement as HTMLElement | null)?.blur()

/** Redirects to /login when there is no session. */
export function ProtectedRoute() {
  const user = useAuthStore((s) => s.user)
  const location = useLocation()
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname }} />
  return <MainLayout />
}

function ThemeToggle() {
  const { theme, toggle } = useThemeStore()
  const dark = theme === 'nikan-dark'
  return (
    <button className="btn btn-ghost btn-circle" onClick={toggle} aria-label={dark ? 'حالت روشن' : 'حالت تاریک'} title={dark ? 'حالت روشن' : 'حالت تاریک'}>
      {dark ? <Sun className="size-5" /> : <Moon className="size-5" />}
    </button>
  )
}

function UserMenu() {
  const user = useAuthStore((s) => s.user)!
  const logout = useAuthStore((s) => s.logout)
  const nav = useNavigate()

  return (
    <div className="dropdown dropdown-end">
      <div tabIndex={0} role="button" className="flex items-center gap-2 rounded-full p-1 ps-3 transition-colors hover:bg-base-200" aria-label="منوی کاربر">
        <span className="hidden text-end leading-tight md:block">
          <span className="block text-sm font-bold">{user.name}</span>
          <span className="block text-[11px] text-base-content/50">{roleLabel[user.role]}</span>
        </span>
        <Avatar name={user.name} size="md" presence="online" />
      </div>
      <ul tabIndex={0} className="dropdown-content menu z-50 mt-2 w-56 rounded-2xl border border-base-300 bg-base-100 p-2 shadow-xl">
        <li className="menu-title px-3 pb-1">
          <span className="block truncate">{user.email}</span>
        </li>
        <li><button onClick={() => { closeDropdown(); nav('/settings') }}><User className="size-4" /> پروفایل من</button></li>
        <li><button onClick={() => { closeDropdown(); nav('/settings') }}><Settings className="size-4" /> تنظیمات</button></li>
        <li className="mt-1 border-t border-base-300/60 pt-1">
          <button
            className="text-error"
            onClick={() => {
              closeDropdown()
              logout()
              toast.success('با موفقیت از سیستم خارج شدید')
              nav('/login', { replace: true })
            }}
          >
            <LogOut className="size-4" /> خروج از حساب
          </button>
        </li>
      </ul>
    </div>
  )
}

export function MainLayout() {
  const [open, setOpen] = useState(false)
  const { pathname } = useLocation()

  return (
    <div className="flex h-dvh overflow-hidden bg-base-200">
      <Sidebar open={open} onClose={() => setOpen(false)} />
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="z-30 flex h-16 shrink-0 items-center gap-2 border-b border-base-300/60 bg-base-100/80 px-3 backdrop-blur-md sm:gap-3 sm:px-6">
          <button className="btn btn-ghost btn-circle lg:hidden" onClick={() => setOpen(true)} aria-label="باز کردن منو">
            <Menu className="size-5" />
          </button>
          <GlobalSearch />
          <div className="ms-auto flex items-center gap-1">
            <ThemeToggle />
            <NotificationsMenu />
            <UserMenu />
          </div>
        </header>
        <main className="flex-1 overflow-y-auto p-4 sm:p-6">
          <motion.div key={pathname} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.25 }} className="mx-auto max-w-[1500px]">
            <Suspense fallback={<PageSkeleton />}>
              <Outlet />
            </Suspense>
          </motion.div>
        </main>
      </div>
    </div>
  )
}
