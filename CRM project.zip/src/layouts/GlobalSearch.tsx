import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Package, Receipt, Search, User } from 'lucide-react'
import { useList } from '../hooks/useData'
import { Avatar } from '../components/ui/Avatar'
import { fullName, toman } from '../utils/format'

/** Topbar search across customers, products and invoices. Press "/" to focus. */
export function GlobalSearch() {
  const [q, setQ] = useState('')
  const [open, setOpen] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const nav = useNavigate()
  const { data: customers } = useList('customers')
  const { data: products } = useList('products')
  const { data: sales } = useList('sales')

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement).tagName
      if (e.key === '/' && tag !== 'INPUT' && tag !== 'TEXTAREA') {
        e.preventDefault()
        inputRef.current?.focus()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  const results = useMemo(() => {
    const t = q.trim().toLowerCase()
    if (t.length < 2) return null
    return {
      customers: customers
        .filter((c) => `${fullName(c)} ${c.company} ${c.phone} ${c.email}`.toLowerCase().includes(t))
        .slice(0, 4),
      products: products.filter((p) => `${p.name} ${p.sku}`.toLowerCase().includes(t)).slice(0, 3),
      sales: sales.filter((s) => s.number.toLowerCase().includes(t)).slice(0, 3),
    }
  }, [q, customers, products, sales])

  const go = (path: string) => {
    setOpen(false)
    setQ('')
    nav(path)
  }
  const empty = results && !results.customers.length && !results.products.length && !results.sales.length

  return (
    <div className="relative w-full max-w-md">
      <label className="input input-sm h-10 w-full bg-base-200/70 border-transparent focus-within:border-primary focus-within:bg-base-100">
        <Search className="size-4 text-base-content/50" />
        <input
          ref={inputRef}
          value={q}
          onChange={(e) => { setQ(e.target.value); setOpen(true) }}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
          placeholder="جستجوی مشتری، محصول، فاکتور..."
          aria-label="جستجوی سراسری"
        />
        <kbd className="kbd kbd-sm hidden sm:inline-flex">/</kbd>
      </label>

      {open && results && (
        <div className="absolute inset-x-0 top-12 z-50 max-h-96 overflow-y-auto rounded-2xl border border-base-300 bg-base-100 p-2 shadow-xl">
          {empty && <p className="p-4 text-center text-sm text-base-content/60">نتیجه‌ای یافت نشد</p>}
          {results.customers.length > 0 && (
            <Group icon={User} title="مشتریان">
              {results.customers.map((c) => (
                <Row key={c.id} onClick={() => go(`/customers/${c.id}`)}>
                  <Avatar name={fullName(c)} size="sm" />
                  <span className="flex-1 truncate">{fullName(c)}</span>
                  <span className="truncate text-xs text-base-content/50">{c.company}</span>
                </Row>
              ))}
            </Group>
          )}
          {results.products.length > 0 && (
            <Group icon={Package} title="محصولات">
              {results.products.map((p) => (
                <Row key={p.id} onClick={() => go(`/inventory?q=${encodeURIComponent(p.sku)}`)}>
                  <span className="flex-1 truncate">{p.name}</span>
                  <span className="text-xs text-base-content/50">{toman(p.price)}</span>
                </Row>
              ))}
            </Group>
          )}
          {results.sales.length > 0 && (
            <Group icon={Receipt} title="فاکتورها">
              {results.sales.map((s) => (
                <Row key={s.id} onClick={() => go(`/sales?q=${encodeURIComponent(s.number)}`)}>
                  <span className="ltr-text flex-1">{s.number}</span>
                  <span className="text-xs text-base-content/50">{toman(s.total)}</span>
                </Row>
              ))}
            </Group>
          )}
        </div>
      )}
    </div>
  )
}

function Group({ icon: Icon, title, children }: { icon: typeof User; title: string; children: React.ReactNode }) {
  return (
    <div className="mb-1">
      <p className="flex items-center gap-1.5 px-2 py-1 text-[11px] font-semibold text-base-content/40">
        <Icon className="size-3" /> {title}
      </p>
      {children}
    </div>
  )
}
function Row({ children, onClick }: { children: React.ReactNode; onClick: () => void }) {
  return (
    <button
      type="button"
      onMouseDown={(e) => e.preventDefault()}
      onClick={onClick}
      className="flex w-full items-center gap-2 rounded-xl px-2 py-2 text-start text-sm hover:bg-base-200"
    >
      {children}
    </button>
  )
}
