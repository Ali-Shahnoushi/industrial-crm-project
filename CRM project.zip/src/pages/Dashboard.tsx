import { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts'
import {
  AlertTriangle, ArrowLeft, CalendarCheck, DollarSign, Filter, Phone, Plus, Receipt, ShoppingCart, StickyNote, UserPlus, Users, Video, Mail,
} from 'lucide-react'
import { PageHeader } from '../components/ui/PageHeader'
import { StatCard } from '../components/ui/StatCard'
import { ChartCard, ChartTooltip, axisStyle } from '../components/ui/Chart'
import { Avatar } from '../components/ui/Avatar'
import { StatusBadge } from '../components/ui/StatusBadge'
import { useList, useLookup, useUpdate } from '../hooks/useData'
import { useAuthStore } from '../store/useAuthStore'
import { inWindow, monthlySeries, paid, pctChange, revenueByCategory, sum } from '../utils/analytics'
import { CHART_COLORS, invoiceStatus, leadStages, priority } from '../utils/meta'
import { compact, compactToman, cx, dateFa, fullName, num, relativeFa, toman, weekdayFa } from '../utils/format'
import type { ActivityType } from '../types'

const actIcon: Record<ActivityType, typeof Phone> = { call: Phone, meeting: Video, email: Mail, note: StickyNote }

export default function Dashboard() {
  const user = useAuthStore((s) => s.user)!
  const nav = useNavigate()
  const [range, setRange] = useState<6 | 12>(12)

  const { data: sales, isLoading } = useList('sales')
  const { data: customers } = useList('customers')
  const { data: leads } = useList('leads')
  const { data: products } = useList('products')
  const { data: tasks } = useList('tasks')
  const { data: activities } = useList('activities')
  const { map: productMap } = useLookup('products')
  const { map: customerMap } = useLookup('customers')
  const updateTask = useUpdate('tasks')

  const kpi = useMemo(() => {
    const cur = paid(inWindow(sales, 30))
    const prev = paid(inWindow(sales, 60, 30))
    const newCust = customers.filter((c) => Date.now() - +new Date(c.createdAt) < 30 * 86_400_000).length
    const open = leads.filter((l) => l.stage !== 'won' && l.stage !== 'lost')
    return {
      revenue: sum(cur),
      revenueDelta: pctChange(sum(cur), sum(prev)),
      orders: cur.length,
      ordersDelta: pctChange(cur.length, prev.length),
      activeCustomers: customers.filter((c) => c.status === 'active' || c.status === 'vip').length,
      newCust,
      pipelineValue: open.reduce((t, l) => t + l.value, 0),
      openLeads: open.length,
    }
  }, [sales, customers, leads])

  const series = useMemo(() => monthlySeries(sales, productMap, range), [sales, productMap, range])
  const categories = useMemo(() => revenueByCategory(sales, productMap), [sales, productMap])
  const funnel = useMemo(
    () => leadStages.filter((s) => s.id !== 'lost').map((s) => ({ name: s.label, value: leads.filter((l) => l.stage === s.id).length })),
    [leads],
  )
  const recent = useMemo(() => [...sales].sort((a, b) => +new Date(b.date) - +new Date(a.date)).slice(0, 6), [sales])
  const myTasks = useMemo(
    () => tasks.filter((t) => t.status !== 'done').sort((a, b) => +new Date(a.dueDate) - +new Date(b.dueDate)).slice(0, 5),
    [tasks],
  )
  const lowStock = useMemo(() => products.filter((p) => p.stock <= p.minStock).sort((a, b) => a.stock - b.stock).slice(0, 5), [products])
  const timeline = useMemo(() => activities.slice(0, 5), [activities])

  const today = new Date()

  return (
    <>
      <PageHeader
        title={`سلام ${user.name.split(' ')[0]} 👋`}
        subtitle={`${weekdayFa(today)}، ${dateFa(today)} — نگاهی به وضعیت کسب‌وکار شما`}
        actions={
          <>
            <button className="btn btn-sm" onClick={() => nav('/customers?new=1')}><UserPlus className="size-4" /> مشتری جدید</button>
            <button className="btn btn-sm btn-primary" onClick={() => nav('/sales?new=1')}><Plus className="size-4" /> فاکتور جدید</button>
          </>
        }
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard title="درآمد ۳۰ روز اخیر" value={compactToman(kpi.revenue)} icon={DollarSign} tone="primary" delta={kpi.revenueDelta} hint="نسبت به ماه قبل" loading={isLoading} />
        <StatCard title="سفارش‌های پرداخت‌شده" value={num(kpi.orders)} icon={ShoppingCart} tone="success" delta={kpi.ordersDelta} hint="نسبت به ماه قبل" loading={isLoading} />
        <StatCard title="مشتریان فعال" value={num(kpi.activeCustomers)} icon={Users} tone="secondary" hint={`${num(kpi.newCust)} مشتری جدید در ۳۰ روز`} loading={isLoading} />
        <StatCard title="ارزش کاریز فروش" value={compactToman(kpi.pipelineValue)} icon={Filter} tone="warning" hint={`${num(kpi.openLeads)} فرصت فروش باز`} loading={isLoading} />
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-12">
        <ChartCard
          className="xl:col-span-8"
          title="روند فروش"
          subtitle="درآمد ماهانه (میلیون تومان)"
          actions={
            <div className="join">
              {([6, 12] as const).map((r) => (
                <button key={r} className={cx('btn btn-xs join-item', range === r && 'btn-primary')} onClick={() => setRange(r)}>
                  {num(r)} ماه
                </button>
              ))}
            </div>
          }
        >
          <div className="h-72 w-full" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={series} margin={{ top: 8, right: 0, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="gRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={CHART_COLORS[0]} stopOpacity={0.4} />
                    <stop offset="95%" stopColor={CHART_COLORS[0]} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid vertical={false} stroke={axisStyle.grid} strokeOpacity={0.1} />
                <XAxis dataKey="label" reversed tickLine={false} axisLine={false} tick={axisStyle.tick} />
                <YAxis orientation="right" width={44} tickLine={false} axisLine={false} tick={axisStyle.tick} tickFormatter={(v: number) => num(Math.round(v / 1e6))} />
                <Tooltip content={<ChartTooltip format={(v) => toman(v)} />} />
                <Area type="monotone" dataKey="revenue" name="درآمد" stroke={CHART_COLORS[0]} strokeWidth={2.5} fill="url(#gRev)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        <ChartCard className="xl:col-span-4" title="فروش بر اساس دسته‌بندی" subtitle="سهم هر دسته از درآمد">
          <div className="h-72 w-full" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={categories} dataKey="value" nameKey="name" innerRadius="55%" outerRadius="80%" paddingAngle={3} stroke="none">
                  {categories.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
                </Pie>
                <Tooltip content={<ChartTooltip format={(v) => toman(v)} />} />
                <Legend verticalAlign="bottom" iconType="circle" wrapperStyle={{ fontSize: 11, direction: 'rtl' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-12">
        <section className="card-surface overflow-hidden xl:col-span-7">
          <header className="flex items-center justify-between px-5 pt-5">
            <h2 className="font-bold">آخرین فاکتورها</h2>
            <Link to="/sales" className="btn btn-ghost btn-xs text-primary">مشاهده همه <ArrowLeft className="size-3.5" /></Link>
          </header>
          <div className="overflow-x-auto">
            <table className="table">
              <thead>
                <tr><th>شماره</th><th>مشتری</th><th>مبلغ</th><th>وضعیت</th><th>تاریخ</th></tr>
              </thead>
              <tbody>
                {recent.map((s) => {
                  const c = customerMap.get(s.customerId)
                  return (
                    <tr key={s.id} className="hover:bg-base-200/50">
                      <td className="ltr-text text-xs font-semibold">{s.number}</td>
                      <td>
                        {c && (
                          <Link to={`/customers/${c.id}`} className="flex items-center gap-2 hover:text-primary">
                            <Avatar name={fullName(c)} size="xs" /> <span className="truncate">{fullName(c)}</span>
                          </Link>
                        )}
                      </td>
                      <td className="whitespace-nowrap font-semibold">{compactToman(s.total)}</td>
                      <td><StatusBadge meta={invoiceStatus[s.status]} /></td>
                      <td className="whitespace-nowrap text-xs text-base-content/60">{relativeFa(s.date)}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </section>

        <ChartCard className="xl:col-span-5" title="قیف فروش" subtitle="تعداد فرصت‌ها در هر مرحله">
          <div className="h-64 w-full" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={funnel} layout="vertical" margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                <XAxis type="number" hide reversed />
                <YAxis type="category" dataKey="name" orientation="right" width={92} tickLine={false} axisLine={false} tick={axisStyle.tick} />
                <Tooltip cursor={{ fill: 'currentColor', fillOpacity: 0.05 }} content={<ChartTooltip format={(v) => `${num(v)} فرصت`} />} />
                <Bar dataKey="value" name="تعداد" radius={[8, 8, 8, 8]} barSize={22}>
                  {funnel.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
        <section className="card-surface p-5">
          <header className="mb-3 flex items-center justify-between">
            <h2 className="flex items-center gap-2 font-bold"><CalendarCheck className="size-4 text-primary" /> وظایف پیش‌رو</h2>
            <Link to="/tasks" className="text-xs text-primary">همه</Link>
          </header>
          <ul className="space-y-1">
            {myTasks.map((t) => {
              const overdue = new Date(t.dueDate) < today
              return (
                <li key={t.id} className="flex items-start gap-3 rounded-xl p-2 hover:bg-base-200/60">
                  <input
                    type="checkbox"
                    className="checkbox checkbox-primary checkbox-sm mt-0.5"
                    aria-label={`انجام شد: ${t.title}`}
                    onChange={() => updateTask.mutate({ id: t.id, status: 'done' })}
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{t.title}</p>
                    <p className={cx('text-xs', overdue ? 'text-error' : 'text-base-content/50')}>
                      {overdue ? 'عقب‌افتاده — ' : ''}{dateFa(t.dueDate)}
                    </p>
                  </div>
                  <StatusBadge meta={priority[t.priority]} />
                </li>
              )
            })}
            {!myTasks.length && <li className="py-6 text-center text-sm text-base-content/60">همه وظایف انجام شده 🎉</li>}
          </ul>
        </section>

        <section className="card-surface p-5">
          <h2 className="mb-3 font-bold">آخرین فعالیت‌ها</h2>
          <ul className="space-y-3">
            {timeline.map((a) => {
              const Icon = actIcon[a.type]
              const c = customerMap.get(a.customerId)
              return (
                <li key={a.id} className="flex gap-3">
                  <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary"><Icon className="size-4" /></span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{a.title}</p>
                    <p className="truncate text-xs text-base-content/60">
                      {c ? <Link className="hover:text-primary" to={`/customers/${c.id}`}>{fullName(c)}</Link> : '—'} · {relativeFa(a.date)}
                    </p>
                  </div>
                </li>
              )
            })}
          </ul>
        </section>

        <section className="card-surface p-5">
          <header className="mb-3 flex items-center justify-between">
            <h2 className="flex items-center gap-2 font-bold"><AlertTriangle className="size-4 text-warning" /> هشدار موجودی</h2>
            <Link to="/inventory" className="text-xs text-primary">انبار</Link>
          </header>
          <ul className="space-y-3">
            {lowStock.map((p) => {
              const pct = Math.min(100, (p.stock / Math.max(p.minStock, 1)) * 100)
              return (
                <li key={p.id}>
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="truncate font-medium">{p.name}</span>
                    <span className={cx('shrink-0 text-xs font-bold', p.stock === 0 ? 'text-error' : 'text-warning')}>
                      {p.stock === 0 ? 'ناموجود' : `${num(p.stock)} ${p.unit}`}
                    </span>
                  </div>
                  <progress className={cx('progress mt-1 h-1.5', p.stock === 0 ? 'progress-error' : 'progress-warning')} value={pct} max={100} />
                </li>
              )
            })}
            {!lowStock.length && <li className="py-6 text-center text-sm text-base-content/60">موجودی همه کالاها کافی است</li>}
          </ul>
        </section>
      </div>
      <p className="mt-6 flex items-center justify-center gap-2 text-xs text-base-content/40">
        <Receipt className="size-3.5" /> مجموع درآمد ثبت‌شده: {compact(sum(paid(sales)))} تومان
      </p>
    </>
  )
}
