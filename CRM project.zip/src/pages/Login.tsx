import { useState } from 'react'
import { Navigate, useLocation, useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import toast from 'react-hot-toast'
import { BarChart3, Eye, EyeOff, Lock, Mail, Moon, ShieldCheck, Sun, Users, Zap } from 'lucide-react'
import { Logo } from '../layouts/Sidebar'
import { Field } from '../components/ui/Field'
import { useAuthStore } from '../store/useAuthStore'
import { useThemeStore } from '../store/useThemeStore'

const schema = z.object({
  email: z.email('ایمیل معتبر وارد کنید'),
  password: z.string().min(4, 'گذرواژه حداقل ۴ کاراکتر است'),
})
type FormValues = z.infer<typeof schema>

const DEMO = { email: 'admin@nikan.ir', password: '123456' }

const features = [
  { icon: Users, title: 'مدیریت یکپارچه مشتریان', text: 'تمام تعاملات، فاکتورها و یادداشت‌ها در یک پروفایل.' },
  { icon: BarChart3, title: 'گزارش‌های لحظه‌ای فروش', text: 'نمودارهای تعاملی برای تصمیم‌گیری سریع‌تر.' },
  { icon: Zap, title: 'کاریز فروش هوشمند', text: 'پیگیری لیدها با کانبان و کشیدن و رها کردن.' },
]

export default function Login() {
  const user = useAuthStore((s) => s.user)
  const login = useAuthStore((s) => s.login)
  const { theme, toggle } = useThemeStore()
  const nav = useNavigate()
  const location = useLocation()
  const [show, setShow] = useState(false)
  const [error, setError] = useState('')

  const { register, handleSubmit, setValue, formState: { errors, isSubmitting } } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: DEMO,
  })

  const from = (location.state as { from?: string } | null)?.from ?? '/'
  if (user) return <Navigate to={from} replace />

  const onSubmit = async (v: FormValues) => {
    setError('')
    const res = await login(v.email, v.password)
    if (res.ok) {
      toast.success('خوش آمدید 👋')
      nav(from, { replace: true })
    } else setError(res.error)
  }

  return (
    <div className="grid min-h-dvh bg-base-100 lg:grid-cols-2">
      {/* Form side */}
      <div className="relative flex flex-col justify-center px-6 py-10 sm:px-12 lg:px-20">
        <button onClick={toggle} className="btn btn-ghost btn-circle absolute start-4 top-4" aria-label="تغییر پوسته">
          {theme === 'nikan-dark' ? <Sun className="size-5" /> : <Moon className="size-5" />}
        </button>

        <div className="mx-auto w-full max-w-md">
          <Logo size="lg" />
          <h1 className="mt-10 text-3xl font-extrabold">ورود به حساب کاربری</h1>
          <p className="mt-2 text-base-content/60">برای ادامه، اطلاعات حساب خود را وارد کنید.</p>

          <form onSubmit={handleSubmit(onSubmit)} className="mt-8 space-y-2" noValidate>
            <Field label="ایمیل" error={errors.email?.message}>
              <label className={`input w-full ${errors.email ? 'input-error' : ''}`}>
                <Mail className="size-4 text-base-content/50" />
                <input type="email" dir="ltr" className="text-start" autoComplete="username" placeholder="name@company.ir" {...register('email')} />
              </label>
            </Field>
            <Field label="گذرواژه" error={errors.password?.message}>
              <label className={`input w-full ${errors.password ? 'input-error' : ''}`}>
                <Lock className="size-4 text-base-content/50" />
                <input type={show ? 'text' : 'password'} dir="ltr" className="text-start" autoComplete="current-password" placeholder="••••••••" {...register('password')} />
                <button type="button" onClick={() => setShow((s) => !s)} aria-label={show ? 'پنهان کردن گذرواژه' : 'نمایش گذرواژه'} className="text-base-content/50 hover:text-base-content">
                  {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </label>
            </Field>

            <div className="flex items-center justify-between pb-2 pt-1 text-sm">
              <label className="flex cursor-pointer items-center gap-2">
                <input type="checkbox" className="checkbox checkbox-primary checkbox-sm" defaultChecked />
                مرا به خاطر بسپار
              </label>
              <button type="button" className="link link-primary no-underline" onClick={() => toast('در نسخه نمایشی فعال نیست', { icon: 'ℹ️' })}>
                فراموشی گذرواژه؟
              </button>
            </div>

            {error && (
              <div role="alert" className="alert alert-error alert-soft text-sm">
                <ShieldCheck className="size-4" /> {error}
              </div>
            )}

            <button type="submit" className="btn btn-primary btn-block h-12 text-base" disabled={isSubmitting}>
              {isSubmitting && <span className="loading loading-spinner" />}
              ورود
            </button>
          </form>

          <div className="mt-6 rounded-2xl border border-dashed border-primary/40 bg-primary/5 p-4 text-sm">
            <p className="font-semibold text-primary">حساب نمایشی</p>
            <p className="mt-1 text-base-content/70">
              <span className="ltr-text">{DEMO.email}</span> — گذرواژه: <span className="ltr-text">{DEMO.password}</span>
            </p>
            <button
              type="button"
              className="btn btn-sm btn-primary btn-soft mt-3"
              onClick={() => { setValue('email', DEMO.email); setValue('password', DEMO.password); handleSubmit(onSubmit)() }}
            >
              ورود سریع با حساب دمو
            </button>
          </div>
        </div>
      </div>

      {/* Brand side */}
      <div className="gradient-brand relative hidden overflow-hidden p-12 text-white lg:flex lg:flex-col lg:justify-between">
        <div className="pointer-events-none absolute -end-24 -top-24 size-96 rounded-full bg-white/10 blur-2xl" />
        <div className="pointer-events-none absolute -bottom-32 -start-20 size-[28rem] rounded-full bg-black/10 blur-3xl" />

        <div className="relative">
          <p className="text-sm font-medium text-white/70">سامانه مدیریت ارتباط با مشتری</p>
          <h2 className="mt-3 max-w-md text-4xl font-black leading-snug">مشتریان‌تان را بشناسید، فروش‌تان را رشد دهید.</h2>
        </div>

        <ul className="relative space-y-4">
          {features.map(({ icon: Icon, title, text }) => (
            <li key={title} className="flex items-start gap-4 rounded-2xl bg-white/10 p-4 backdrop-blur-md ring-1 ring-white/15">
              <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-white/20"><Icon className="size-5" /></span>
              <div>
                <p className="font-bold">{title}</p>
                <p className="mt-0.5 text-sm text-white/75">{text}</p>
              </div>
            </li>
          ))}
        </ul>

        <p className="relative text-xs text-white/60">© نیکان — نسخه نمایشی (داده‌ها ساختگی است)</p>
      </div>
    </div>
  )
}
