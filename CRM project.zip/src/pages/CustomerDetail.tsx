import { useMemo, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import {
  ArrowRight, Building2, CalendarClock, Mail, MapPin, MessageSquarePlus, Pencil, Phone, ShoppingBag, StickyNote, Trash2, TrendingUp, User, Video, Wallet,
} from 'lucide-react'
import { Avatar } from '../components/ui/Avatar'
import { StatusBadge } from '../components/ui/StatusBadge'
import { StatCard } from '../components/ui/StatCard'
import { ChartCard, ChartTooltip, axisStyle } from '../components/ui/Chart'
import { ConfirmDialog, Modal } from '../components/ui/Modal'
import { EmptyState, Field, PageSkeleton } from '../components/ui/Field'
import { CustomerFormModal } from '../components/customers/CustomerFormModal'
import { useCreate, useList, useLookup, useRemove } from '../hooks/useData'
import { useAuthStore } from '../store/useAuthStore'
import { monthlySeries, paid } from '../utils/analytics'
import { activityType, CHART_COLORS, customerStatus, invoiceStatus, priority, ticketStatus } from '../utils/meta'
import { compactToman, cx, dateFa, dateTimeFa, fullName, num, phoneFa, relativeFa, toman } from '../utils/format'
import type { ActivityType } from '../types'

const actIcon: Record<ActivityType, typeof Phone> = { call: Phone, meeting: Video, email: Mail, note: StickyNote }
const TABS = [
  { id: 'overview', label: 'نمای کلی' },
  { id: 'purchases', label: 'سفارش‌ها' },
  { id: 'activities', label: 'فعالیت‌ها' },
  { id: 'tickets', label: 'تیکت‌ها' },
] as const
type Tab = (typeof TABS)[number]['id']

export default function CustomerDetail() {
  const { id } = useParams()
  const nav = useNavigate()
  const me = useAuthStore((s) => s.user)!
  const [tab, setTab] = useState<Tab>('overview')
  const [editOpen, setEditOpen] = useState(false)
  const [delOpen, setDelOpen] = useState(false)
  const [actOpen, setActOpen] = useState(false)

  const { data: customers, isLoading } = useList('customers')
  const { data: sales } = useList('sales')
  const { data: activities } = useList('activities')
  const { data: tickets } = useList('tickets')
  const { map: users } = useLookup('users')
  const { map: products } = useLookup('products')
  const remove = useRemove('customers', { success: 'مشتری حذف شد' })

  const customer = customers.find((c) => c.id === id)
  const mySales = useMemo(() => sales.filter((s) => s.customerId === id).sort((a, b) => +new Date(b.date) - +new Date(a.date)), [sales, id])
  const myActs = useMemo(() => activities.filter((a) => a.customerId === id).sort((a, b) => +new Date(b.date) - +new Date(a.date)), [activities, id])
  const myTickets = useMemo(() => tickets.filter((t) => t.customerId === id), [tickets, id])
  const series = useMemo(() => monthlySeries(mySales, products, 6), [mySales, products])

  if (isLoading) return <PageSkeleton />
  if (!customer) {
    return (
      <EmptyState
        title="مشتری پیدا نشد"
        description="ممکن است این مشتری حذف شده باشد."
        action={<Link to="/customers" className="btn btn-primary btn-sm">بازگشت به لیست مشتریان</Link>}
      />
    )
  }

  const paidSales = paid(mySales)
  const avg = paidSales.length ? customer.totalSpent / paidSales.length : 0
  const owner = users.get(customer.assignedTo)

  return (
    <>
      <Link to="/customers" className="mb-4 inline-flex items-center gap-1 text-sm text-base-content/60 hover:text-primary">
        <ArrowRight className="size-4" /> بازگشت به مشتریان
      </Link>

      {/* Profile header */}
      <section className="card-surface relative overflow-hidden p-5 sm:p-6">
        <div className="gradient-brand absolute inset-x-0 top-0 h-20 opacity-90" />
        <div className="relative mt-6 flex flex-col gap-4 sm:flex-row sm:items-end">
          <div className="rounded-full ring-4 ring-base-100"><Avatar name={fullName(customer)} size="xl" /></div>
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-2xl font-extrabold">{fullName(customer)}</h1>
              <StatusBadge meta={customerStatus[customer.status]} />
            </div>
            <p className="mt-1 flex items-center gap-1.5 text-sm text-base-content/60">
              {customer.type === 'company' ? <Building2 className="size-4" /> : <User className="size-4" />}
              {customer.company || 'مشتری حقیقی'} · {customer.city}
            </p>
            {customer.tags.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1.5">{customer.tags.map((t) => <span key={t} className="badge badge-outline badge-sm">{t}</span>)}</div>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            <a href={`tel:${customer.phone}`} className="btn btn-sm btn-success btn-soft"><Phone className="size-4" /> تماس</a>
            <a href={`mailto:${customer.email}`} className="btn btn-sm btn-info btn-soft"><Mail className="size-4" /> ایمیل</a>
            <button className="btn btn-sm" onClick={() => setEditOpen(true)}><Pencil className="size-4" /> ویرایش</button>
            <button className="btn btn-sm btn-error btn-soft" onClick={() => setDelOpen(true)} aria-label="حذف مشتری"><Trash2 className="size-4" /></button>
          </div>
        </div>
      </section>

      <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard title="مجموع خرید" value={compactToman(customer.totalSpent)} icon={Wallet} tone="primary" />
        <StatCard title="تعداد سفارش" value={num(paidSales.length)} icon={ShoppingBag} tone="success" />
        <StatCard title="میانگین سفارش" value={avg ? compactToman(avg) : '—'} icon={TrendingUp} tone="secondary" />
        <StatCard title="آخرین خرید" value={customer.lastPurchase ? relativeFa(customer.lastPurchase) : 'بدون خرید'} icon={CalendarClock} tone="warning" />
      </div>

      <div role="tablist" className="tabs tabs-border mt-6">
        {TABS.map((t) => (
          <button key={t.id} role="tab" className={cx('tab', tab === t.id && 'tab-active font-bold')} onClick={() => setTab(t.id)}>
            {t.label}
            {t.id === 'activities' && <span className="badge badge-sm ms-2">{num(myActs.length)}</span>}
            {t.id === 'tickets' && myTickets.length > 0 && <span className="badge badge-sm ms-2">{num(myTickets.length)}</span>}
          </button>
        ))}
      </div>

      {tab === 'overview' && (
        <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
          <section className="card-surface p-5 lg:col-span-1">
            <h2 className="mb-4 font-bold">اطلاعات تماس</h2>
            <dl className="space-y-4 text-sm">
              <Info icon={Phone} label="موبایل" value={phoneFa(customer.phone)} />
              <Info icon={Mail} label="ایمیل" value={<span className="ltr-text">{customer.email}</span>} />
              <Info icon={MapPin} label="آدرس" value={`${customer.city}${customer.address ? '، ' + customer.address : ''}`} />
              <Info icon={User} label="کارشناس مسئول" value={owner ? <span className="flex items-center gap-2"><Avatar name={owner.name} size="xs" />{owner.name}</span> : '—'} />
              <Info icon={CalendarClock} label="تاریخ ثبت" value={dateFa(customer.createdAt)} />
              <Info icon={StickyNote} label="منبع جذب" value={customer.source} />
            </dl>
            {customer.notes && (
              <div className="mt-5 rounded-xl bg-warning/10 p-3 text-sm leading-7"><b className="text-warning">یادداشت: </b>{customer.notes}</div>
            )}
          </section>

          <ChartCard className="lg:col-span-2" title="خرید ماهانه مشتری" subtitle="۶ ماه اخیر (میلیون تومان)">
            <div className="h-64 w-full" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={series}>
                  <CartesianGrid vertical={false} stroke={axisStyle.grid} strokeOpacity={0.1} />
                  <XAxis dataKey="label" reversed tickLine={false} axisLine={false} tick={axisStyle.tick} />
                  <YAxis orientation="right" width={40} tickLine={false} axisLine={false} tick={axisStyle.tick} tickFormatter={(v: number) => num(Math.round(v / 1e6))} />
                  <Tooltip cursor={{ fill: 'currentColor', fillOpacity: 0.05 }} content={<ChartTooltip format={(v) => toman(v)} />} />
                  <Bar dataKey="revenue" name="خرید" fill={CHART_COLORS[0]} radius={[8, 8, 0, 0]} maxBarSize={36} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>
        </div>
      )}

      {tab === 'purchases' && (
        <section className="card-surface mt-4 overflow-x-auto">
          {mySales.length ? (
            <table className="table">
              <thead><tr><th>شماره فاکتور</th><th>تاریخ</th><th>اقلام</th><th>مبلغ</th><th>وضعیت</th></tr></thead>
              <tbody>
                {mySales.map((s) => (
                  <tr key={s.id} className="hover:bg-base-200/50">
                    <td className="ltr-text font-semibold">{s.number}</td>
                    <td className="whitespace-nowrap">{dateFa(s.date)}</td>
                    <td className="max-w-64 truncate text-sm text-base-content/70">{s.items.map((i) => i.name).join('، ')}</td>
                    <td className="whitespace-nowrap font-semibold">{toman(s.total)}</td>
                    <td><StatusBadge meta={invoiceStatus[s.status]} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : <EmptyState title="هنوز سفارشی ثبت نشده" />}
        </section>
      )}

      {tab === 'activities' && (
        <section className="card-surface mt-4 p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-bold">تاریخچه تعاملات</h2>
            <button className="btn btn-sm btn-primary" onClick={() => setActOpen(true)}><MessageSquarePlus className="size-4" /> ثبت فعالیت</button>
          </div>
          {myActs.length ? (
            <ol className="relative space-y-5 border-s-2 border-base-300 ps-6">
              {myActs.map((a) => {
                const Icon = actIcon[a.type]
                return (
                  <li key={a.id} className="relative">
                    <span className="absolute -start-[2.15rem] flex size-8 items-center justify-center rounded-full bg-primary text-primary-content ring-4 ring-base-100"><Icon className="size-4" /></span>
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="font-semibold">{a.title}</p>
                      <span className="badge badge-ghost badge-sm">{activityType[a.type].label}</span>
                    </div>
                    <p className="mt-0.5 text-sm text-base-content/70">{a.description}</p>
                    <p className="mt-1 text-xs text-base-content/50">{users.get(a.userId)?.name} · {dateTimeFa(a.date)}</p>
                  </li>
                )
              })}
            </ol>
          ) : <EmptyState title="فعالیتی ثبت نشده" description="اولین تماس یا جلسه را ثبت کنید." />}
        </section>
      )}

      {tab === 'tickets' && (
        <section className="card-surface mt-4 overflow-x-auto">
          {myTickets.length ? (
            <table className="table">
              <thead><tr><th>شماره</th><th>موضوع</th><th>اولویت</th><th>وضعیت</th><th>تاریخ</th></tr></thead>
              <tbody>
                {myTickets.map((t) => (
                  <tr key={t.id}>
                    <td className="ltr-text font-semibold">{t.number}</td>
                    <td>{t.subject}</td>
                    <td><StatusBadge meta={priority[t.priority]} /></td>
                    <td><StatusBadge meta={ticketStatus[t.status]} /></td>
                    <td className="whitespace-nowrap text-xs text-base-content/60">{relativeFa(t.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : <EmptyState title="تیکتی برای این مشتری ثبت نشده" />}
        </section>
      )}

      <CustomerFormModal open={editOpen} onClose={() => setEditOpen(false)} customer={customer} />
      <ActivityModal open={actOpen} onClose={() => setActOpen(false)} customerId={customer.id} userId={me.id} />
      <ConfirmDialog
        open={delOpen}
        onClose={() => setDelOpen(false)}
        title="حذف مشتری"
        danger
        confirmLabel="حذف مشتری"
        loading={remove.isPending}
        message={`آیا از حذف «${fullName(customer)}» اطمینان دارید؟`}
        onConfirm={() => remove.mutate(customer.id, { onSuccess: () => nav('/customers', { replace: true }) })}
      />
    </>
  )
}

function Info({ icon: Icon, label, value }: { icon: typeof Phone; label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-start gap-3">
      <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-base-200 text-base-content/60"><Icon className="size-4" /></span>
      <div className="min-w-0">
        <dt className="text-xs text-base-content/50">{label}</dt>
        <dd className="mt-0.5 font-medium">{value}</dd>
      </div>
    </div>
  )
}

function ActivityModal({ open, onClose, customerId, userId }: { open: boolean; onClose: () => void; customerId: string; userId: string }) {
  const create = useCreate('activities', { success: 'فعالیت ثبت شد' })
  const [type, setType] = useState<ActivityType>('call')
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [touched, setTouched] = useState(false)

  const submit = () => {
    setTouched(true)
    if (title.trim().length < 3) return
    create.mutate(
      { customerId, userId, type, title: title.trim(), description: description.trim(), date: new Date().toISOString() },
      { onSuccess: () => { setTitle(''); setDescription(''); setTouched(false); onClose() } },
    )
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="ثبت فعالیت جدید"
      footer={<>
        <button className="btn btn-ghost" onClick={onClose}>انصراف</button>
        <button className="btn btn-primary" onClick={submit} disabled={create.isPending}>ثبت</button>
      </>}
    >
      <div className="space-y-1">
        <div role="tablist" className="tabs tabs-box mb-2 w-fit">
          {(Object.keys(activityType) as ActivityType[]).map((k) => (
            <button key={k} role="tab" className={cx('tab', type === k && 'tab-active')} onClick={() => setType(k)}>{activityType[k].label}</button>
          ))}
        </div>
        <Field label="عنوان" required error={touched && title.trim().length < 3 ? 'عنوان را وارد کنید' : undefined}>
          <input className="input w-full" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="مثلاً: تماس پیگیری پیش‌فاکتور" />
        </Field>
        <Field label="توضیحات">
          <textarea rows={3} className="textarea w-full" value={description} onChange={(e) => setDescription(e.target.value)} />
        </Field>
      </div>
    </Modal>
  )
}
