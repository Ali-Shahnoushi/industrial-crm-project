import { useEffect, useMemo, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { Download, Eye, MoreVertical, Pencil, Plus, RotateCcw, Trash2, Upload, UserCheck, UserPlus, Users, Wallet } from 'lucide-react'
import { PageHeader } from '../components/ui/PageHeader'
import { StatCard } from '../components/ui/StatCard'
import { SearchInput } from '../components/ui/SearchInput'
import { Pagination } from '../components/ui/Pagination'
import { Avatar } from '../components/ui/Avatar'
import { StatusBadge } from '../components/ui/StatusBadge'
import { ConfirmDialog } from '../components/ui/Modal'
import { EmptyState, TableSkeleton } from '../components/ui/Field'
import { CustomerFormModal } from '../components/customers/CustomerFormModal'
import { ImportModal } from '../components/customers/ImportModal'
import { useList, useLookup, useRemove } from '../hooks/useData'
import { downloadCsv } from '../utils/csv'
import { CITIES, customerStatus } from '../utils/meta'
import { compactToman, cx, dateShort, fullName, num, phoneFa, relativeFa } from '../utils/format'
import type { Customer, CustomerStatus } from '../types'

const PAGE_SIZE = 10
const SORTS = {
  newest: { label: 'جدیدترین', fn: (a: Customer, b: Customer) => +new Date(b.createdAt) - +new Date(a.createdAt) },
  spent: { label: 'بیشترین خرید', fn: (a: Customer, b: Customer) => b.totalSpent - a.totalSpent },
  name: { label: 'نام (الفبا)', fn: (a: Customer, b: Customer) => fullName(a).localeCompare(fullName(b), 'fa') },
  contact: { label: 'آخرین تماس', fn: (a: Customer, b: Customer) => +new Date(b.lastContact) - +new Date(a.lastContact) },
} as const
type SortKey = keyof typeof SORTS

export default function Customers() {
  const [params, setParams] = useSearchParams()
  const { data: customers, isLoading } = useList('customers')
  const { map: users } = useLookup('users')
  const remove = useRemove('customers', { success: 'مشتری حذف شد' })

  const [q, setQ] = useState('')
  const [status, setStatus] = useState<CustomerStatus | 'all'>('all')
  const [city, setCity] = useState('all')
  const [owner, setOwner] = useState('all')
  const [sort, setSort] = useState<SortKey>('newest')
  const [page, setPage] = useState(1)

  const [formOpen, setFormOpen] = useState(false)
  const [editing, setEditing] = useState<Customer | undefined>()
  const [importOpen, setImportOpen] = useState(false)
  const [deleting, setDeleting] = useState<Customer | null>(null)

  // `?new=1` (from the dashboard quick action) opens the create form.
  useEffect(() => {
    if (params.get('new')) {
      setEditing(undefined)
      setFormOpen(true)
      setParams({}, { replace: true })
    }
  }, [params, setParams])

  const stats = useMemo(() => {
    const month = 30 * 86_400_000
    return {
      total: customers.length,
      active: customers.filter((c) => c.status === 'active' || c.status === 'vip').length,
      fresh: customers.filter((c) => Date.now() - +new Date(c.createdAt) < month).length,
      revenue: customers.reduce((t, c) => t + c.totalSpent, 0),
      byStatus: (Object.keys(customerStatus) as CustomerStatus[]).map((k) => ({ k, n: customers.filter((c) => c.status === k).length })),
    }
  }, [customers])

  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase()
    return customers
      .filter((c) => status === 'all' || c.status === status)
      .filter((c) => city === 'all' || c.city === city)
      .filter((c) => owner === 'all' || c.assignedTo === owner)
      .filter((c) => !t || `${fullName(c)} ${c.company} ${c.email} ${c.phone} ${c.tags.join(' ')}`.toLowerCase().includes(t))
      .sort(SORTS[sort].fn)
  }, [customers, q, status, city, owner, sort])

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const safePage = Math.min(page, pageCount)
  const rows = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE)
  const hasFilters = q || status !== 'all' || city !== 'all' || owner !== 'all'
  const clear = () => { setQ(''); setStatus('all'); setCity('all'); setOwner('all'); setPage(1) }

  const exportCsv = () => {
    downloadCsv(
      `nikan-customers-${new Date().toISOString().slice(0, 10)}.csv`,
      filtered.map((c) => ({
        نام: c.firstName,
        'نام خانوادگی': c.lastName,
        شرکت: c.company,
        ایمیل: c.email,
        موبایل: c.phone,
        شهر: c.city,
        وضعیت: customerStatus[c.status].label,
        'مجموع خرید (تومان)': c.totalSpent,
        'تعداد سفارش': c.ordersCount,
        'کارشناس مسئول': users.get(c.assignedTo)?.name ?? '',
        'تاریخ ثبت': dateShort(c.createdAt),
      })),
    )
  }

  const set = <T,>(fn: (v: T) => void) => (v: T) => { fn(v); setPage(1) }

  return (
    <>
      <PageHeader
        title="مشتریان"
        subtitle="مدیریت، جستجو و تحلیل مشتریان سازمان"
        actions={
          <>
            <button className="btn btn-sm" onClick={() => setImportOpen(true)}><Upload className="size-4" /> ایمپورت</button>
            <button className="btn btn-sm" onClick={exportCsv} disabled={!filtered.length}><Download className="size-4" /> اکسپورت</button>
            <button className="btn btn-sm btn-primary" onClick={() => { setEditing(undefined); setFormOpen(true) }}><Plus className="size-4" /> مشتری جدید</button>
          </>
        }
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard title="کل مشتریان" value={num(stats.total)} icon={Users} tone="primary" loading={isLoading} />
        <StatCard title="مشتریان فعال و ویژه" value={num(stats.active)} icon={UserCheck} tone="success" hint={`${num(Math.round((stats.active / Math.max(stats.total, 1)) * 100))}٪ از کل`} loading={isLoading} />
        <StatCard title="مشتریان جدید (۳۰ روز)" value={num(stats.fresh)} icon={UserPlus} tone="info" loading={isLoading} />
        <StatCard title="مجموع خرید مشتریان" value={compactToman(stats.revenue)} icon={Wallet} tone="warning" loading={isLoading} />
      </div>

      {/* status distribution */}
      {stats.total > 0 && (
        <div className="card-surface mt-4 p-4">
          <div className="flex h-2.5 overflow-hidden rounded-full bg-base-200">
            {stats.byStatus.map(({ k, n }) => (
              <div key={k} style={{ width: `${(n / stats.total) * 100}%` }} className={cx('transition-all', k === 'active' && 'bg-success', k === 'vip' && 'bg-primary', k === 'new' && 'bg-info', k === 'inactive' && 'bg-base-content/25')} />
            ))}
          </div>
          <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-xs text-base-content/70">
            {stats.byStatus.map(({ k, n }) => (
              <span key={k} className="flex items-center gap-1.5">
                <span className={cx('size-2 rounded-full', k === 'active' && 'bg-success', k === 'vip' && 'bg-primary', k === 'new' && 'bg-info', k === 'inactive' && 'bg-base-content/25')} />
                {customerStatus[k].label}: <b>{num(n)}</b>
              </span>
            ))}
          </div>
        </div>
      )}

      <section className="card-surface mt-4 overflow-hidden">
        <div className="flex flex-col gap-3 p-4 lg:flex-row lg:items-center">
          <SearchInput value={q} onChange={set(setQ)} placeholder="جستجو بر اساس نام، شرکت، ایمیل، موبایل..." className="lg:max-w-sm" />
          <div className="flex flex-1 flex-wrap items-center gap-2">
            <select className="select select-sm w-auto" value={status} onChange={(e) => set(setStatus)(e.target.value as CustomerStatus | 'all')} aria-label="فیلتر وضعیت">
              <option value="all">همه وضعیت‌ها</option>
              {(Object.keys(customerStatus) as CustomerStatus[]).map((k) => <option key={k} value={k}>{customerStatus[k].label}</option>)}
            </select>
            <select className="select select-sm w-auto" value={city} onChange={(e) => set(setCity)(e.target.value)} aria-label="فیلتر شهر">
              <option value="all">همه شهرها</option>
              {CITIES.map((c) => <option key={c}>{c}</option>)}
            </select>
            <select className="select select-sm w-auto" value={owner} onChange={(e) => set(setOwner)(e.target.value)} aria-label="فیلتر کارشناس">
              <option value="all">همه کارشناسان</option>
              {[...users.values()].filter((u) => ['u-2', 'u-3', 'u-4'].includes(u.id)).map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
            </select>
            <select className="select select-sm w-auto" value={sort} onChange={(e) => setSort(e.target.value as SortKey)} aria-label="مرتب‌سازی">
              {(Object.keys(SORTS) as SortKey[]).map((k) => <option key={k} value={k}>مرتب‌سازی: {SORTS[k].label}</option>)}
            </select>
            {hasFilters && (
              <button className="btn btn-ghost btn-sm text-error" onClick={clear}><RotateCcw className="size-3.5" /> حذف فیلترها</button>
            )}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr>
                <th>مشتری</th>
                <th className="hidden md:table-cell">شرکت</th>
                <th className="hidden lg:table-cell">موبایل</th>
                <th className="hidden xl:table-cell">شهر</th>
                <th>وضعیت</th>
                <th className="hidden sm:table-cell">مجموع خرید</th>
                <th className="hidden xl:table-cell">آخرین تماس</th>
                <th className="w-12" />
              </tr>
            </thead>
            <tbody>
              {isLoading && <TableSkeleton rows={8} cols={6} />}
              {rows.map((c) => (
                <tr key={c.id} className="hover:bg-base-200/50">
                  <td>
                    <Link to={`/customers/${c.id}`} className="flex items-center gap-3">
                      <Avatar name={fullName(c)} />
                      <div className="min-w-0">
                        <p className="font-semibold hover:text-primary">{fullName(c)}</p>
                        <p className="ltr-text truncate text-xs text-base-content/50">{c.email}</p>
                      </div>
                    </Link>
                  </td>
                  <td className="hidden md:table-cell">{c.company || <span className="text-base-content/40">حقیقی</span>}</td>
                  <td className="hidden whitespace-nowrap lg:table-cell">{phoneFa(c.phone)}</td>
                  <td className="hidden xl:table-cell">{c.city}</td>
                  <td><StatusBadge meta={customerStatus[c.status]} /></td>
                  <td className="hidden whitespace-nowrap font-semibold sm:table-cell">{c.totalSpent ? compactToman(c.totalSpent) : '—'}</td>
                  <td className="hidden whitespace-nowrap text-xs text-base-content/60 xl:table-cell">{relativeFa(c.lastContact)}</td>
                  <td>
                    <div className="dropdown dropdown-end">
                      <div tabIndex={0} role="button" className="btn btn-ghost btn-sm btn-circle" aria-label="عملیات"><MoreVertical className="size-4" /></div>
                      <ul tabIndex={0} className="dropdown-content menu z-20 w-44 rounded-2xl border border-base-300 bg-base-100 p-2 shadow-xl">
                        <li><Link to={`/customers/${c.id}`}><Eye className="size-4" /> مشاهده پروفایل</Link></li>
                        <li><button onClick={() => { (document.activeElement as HTMLElement)?.blur(); setEditing(c); setFormOpen(true) }}><Pencil className="size-4" /> ویرایش</button></li>
                        <li><button className="text-error" onClick={() => { (document.activeElement as HTMLElement)?.blur(); setDeleting(c) }}><Trash2 className="size-4" /> حذف</button></li>
                      </ul>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!isLoading && !rows.length && (
            <EmptyState
              title="مشتری‌ای با این مشخصات پیدا نشد"
              description="فیلترها را تغییر دهید یا مشتری جدید اضافه کنید."
              action={hasFilters ? <button className="btn btn-sm" onClick={clear}>حذف فیلترها</button> : undefined}
            />
          )}
        </div>
        <Pagination page={safePage} pageSize={PAGE_SIZE} total={filtered.length} onPage={setPage} />
      </section>

      <CustomerFormModal open={formOpen} onClose={() => setFormOpen(false)} customer={editing} />
      <ImportModal open={importOpen} onClose={() => setImportOpen(false)} />
      <ConfirmDialog
        open={!!deleting}
        onClose={() => setDeleting(null)}
        title="حذف مشتری"
        danger
        confirmLabel="حذف مشتری"
        loading={remove.isPending}
        message={`آیا از حذف «${deleting ? fullName(deleting) : ''}» اطمینان دارید؟ این عملیات قابل بازگشت نیست.`}
        onConfirm={() => deleting && remove.mutate(deleting.id, { onSuccess: () => setDeleting(null) })}
      />
    </>
  )
}
