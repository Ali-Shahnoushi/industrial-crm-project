import { useState } from 'react'
import { Bell, Info, Moon, Palette, Shield, Sun, User as UserIcon } from 'lucide-react'
import { PageHeader } from '../components/ui/PageHeader'
import { Field } from '../components/ui/Field'
import { useAuthStore } from '../store/useAuthStore'
import { useThemeStore } from '../store/useThemeStore'
import { useUpdate } from '../hooks/useData'
import { cx } from '../utils/format'

export default function Settings() {
  const me = useAuthStore(s => s.user)
  const updateProfileStore = useAuthStore(s => s.updateProfile)
  const { theme, toggle } = useThemeStore()
  const updateProfile = useUpdate('users', { success: 'پروفایل با موفقیت بروز شد' })

  const [activeTab, setActiveTab] = useState<'profile' | 'notifications' | 'appearance' | 'about'>('profile')

  const handleSaveProfile = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!me) return
    const fd = new FormData(e.currentTarget)
    
    const updates = {
      name: fd.get('name') as string,
      email: fd.get('email') as string,
      phone: fd.get('phone') as string,
    }

    await updateProfile.mutateAsync({ id: me.id, ...updates })
    // Also update zustand
    updateProfileStore(updates)
  }

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <PageHeader 
        title="تنظیمات" 
        subtitle="مدیریت حساب کاربری، ظاهر سیستم و تنظیمات شخصی"
      />

      <div className="flex flex-col md:flex-row gap-6 items-start">
        {/* Tabs Sidebar */}
        <div className="w-full md:w-64 shrink-0 bg-base-100 rounded-2xl border border-base-200 shadow-sm overflow-hidden">
          <nav className="flex flex-col p-2 space-y-1">
            <button 
              onClick={() => setActiveTab('profile')}
              className={cx("btn btn-sm justify-start", activeTab === 'profile' ? "btn-primary" : "btn-ghost")}
            >
              <UserIcon className="size-4 me-2" />
              حساب کاربری
            </button>
            <button 
              onClick={() => setActiveTab('appearance')}
              className={cx("btn btn-sm justify-start", activeTab === 'appearance' ? "btn-primary" : "btn-ghost")}
            >
              <Palette className="size-4 me-2" />
              ظاهر سیستم
            </button>
            <button 
              onClick={() => setActiveTab('notifications')}
              className={cx("btn btn-sm justify-start", activeTab === 'notifications' ? "btn-primary" : "btn-ghost")}
            >
              <Bell className="size-4 me-2" />
              اعلانات
            </button>
            <div className="divider my-1"></div>
            <button 
              onClick={() => setActiveTab('about')}
              className={cx("btn btn-sm justify-start", activeTab === 'about' ? "btn-primary" : "btn-ghost")}
            >
              <Info className="size-4 me-2" />
              درباره سیستم
            </button>
          </nav>
        </div>

        {/* Content Area */}
        <div className="flex-1 bg-base-100 rounded-2xl border border-base-200 shadow-sm min-h-[500px]">
          {activeTab === 'profile' && me && (
            <div className="p-6 md:p-8 space-y-6">
              <div>
                <h3 className="text-xl font-bold mb-1">حساب کاربری</h3>
                <p className="text-base-content/60 text-sm">اطلاعات شخصی خود را بروزرسانی کنید.</p>
              </div>

              <form onSubmit={handleSaveProfile} className="space-y-5 max-w-md">
                <Field label="نام و نام خانوادگی">
                  <input name="name" className="input input-bordered w-full" defaultValue={me.name} required />
                </Field>

                <Field label="ایمیل">
                  <input name="email" type="email" className="input input-bordered w-full text-left" dir="ltr" defaultValue={me.email} required />
                </Field>

                <Field label="شماره تماس">
                  <input name="phone" className="input input-bordered w-full text-left" dir="ltr" defaultValue={me.phone} />
                </Field>

                <Field label="نقش کاربری (غیرقابل تغییر)">
                  <input className="input input-bordered w-full" value={me.role} disabled />
                </Field>

                <div className="pt-4 border-t border-base-200">
                  <button type="submit" className="btn btn-primary w-full md:w-auto" disabled={updateProfile.isPending}>
                    ذخیره تغییرات
                  </button>
                </div>
              </form>
            </div>
          )}

          {activeTab === 'appearance' && (
            <div className="p-6 md:p-8 space-y-6">
              <div>
                <h3 className="text-xl font-bold mb-1">ظاهر سیستم</h3>
                <p className="text-base-content/60 text-sm">تم و ظاهر محیط کاربری را شخصی‌سازی کنید.</p>
              </div>

              <div className="space-y-4 max-w-md">
                <div className="card bg-base-200/50 border border-base-200">
                  <div className="card-body p-4 flex-row items-center justify-between">
                    <div>
                      <div className="font-bold flex items-center gap-2">
                        {theme === 'nikan-dark' ? <Moon className="size-4" /> : <Sun className="size-4" />}
                        حالت شب / روز
                      </div>
                      <div className="text-xs text-base-content/60 mt-1">تغییر تم رنگی سیستم به تیره یا روشن.</div>
                    </div>
                    <label className="swap swap-rotate text-primary btn btn-circle btn-ghost">
                      <input type="checkbox" checked={theme === 'nikan-dark'} onChange={toggle} />
                      <Sun className="swap-off size-6" />
                      <Moon className="swap-on size-6" />
                    </label>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'notifications' && (
            <div className="p-6 md:p-8 space-y-6">
              <div>
                <h3 className="text-xl font-bold mb-1">تنظیمات اعلانات</h3>
                <p className="text-base-content/60 text-sm">مشخص کنید در چه مواردی به شما اطلاع داده شود.</p>
              </div>

              <div className="space-y-4 max-w-lg">
                {[
                  { id: '1', title: 'ایمیل برای تیکت‌های جدید', desc: 'وقتی مشتری تیکت جدید ثبت می‌کند ایمیل ارسال شود.', on: true },
                  { id: '2', title: 'اطلاع‌رسانی وظایف تخصیص یافته', desc: 'وقتی وظیفه‌ای به شما ارجاع داده می‌شود، اعلان دریافت کنید.', on: true },
                  { id: '3', title: 'هشدار اتمام موجودی انبار', desc: 'وقتی موجودی کالایی کمتر از حداقل می‌شود.', on: false },
                  { id: '4', title: 'پیام‌های جدید در گفتگوها', desc: 'دریافت اعلان برای پیام‌های جدید در چت.', on: true },
                ].map(n => (
                  <label key={n.id} className="card bg-base-200/50 border border-base-200 cursor-pointer hover:border-primary/30 transition-colors">
                    <div className="card-body p-4 flex-row items-start gap-4">
                      <input type="checkbox" className="toggle toggle-primary" defaultChecked={n.on} />
                      <div>
                        <div className="font-bold text-sm">{n.title}</div>
                        <div className="text-xs text-base-content/60 mt-1">{n.desc}</div>
                      </div>
                    </div>
                  </label>
                ))}
                <div className="text-xs text-base-content/50 mt-4">
                  * این تنظیمات فعلا بصورت نمایشی هستند.
                </div>
              </div>
            </div>
          )}

          {activeTab === 'about' && (
            <div className="p-6 md:p-8 space-y-6">
              <div>
                <h3 className="text-xl font-bold mb-1">درباره سیستم CRM</h3>
                <p className="text-base-content/60 text-sm">اطلاعات فنی و مشخصات پروژه.</p>
              </div>

              <div className="prose prose-sm font-sans max-w-none text-base-content">
                <div className="flex items-center gap-3 mb-6 bg-primary/10 p-4 rounded-2xl border border-primary/20 text-primary-content">
                  <Shield className="size-8 text-primary" />
                  <div>
                    <h4 className="m-0 text-primary font-bold">نیکان سیستم</h4>
                    <p className="m-0 opacity-80 text-xs mt-1">نسخه ۱.۰.۰</p>
                  </div>
                </div>

                <p>
                  این نرم‌افزار یک سیستم مدیریت ارتباط با مشتری (CRM) کاملا مدرن و واکنش‌گرا است که بصورت اختصاصی 
                  طراحی و توسعه یافته است.
                </p>

                <h4>تکنولوژی‌های استفاده شده</h4>
                <ul>
                  <li><strong>کتابخانه اصلی:</strong> React 19</li>
                  <li><strong>استایل‌دهی:</strong> Tailwind CSS v4 + DaisyUI 5</li>
                  <li><strong>مدیریت داده‌ها:</strong> Tanstack React Query + Zustand</li>
                  <li><strong>روتینگ:</strong> React Router v7</li>
                  <li><strong>نمودارها:</strong> Recharts</li>
                </ul>

                <div className="alert alert-info mt-8">
                  <Info className="size-5" />
                  <span>تمام داده‌های این سیستم با استفاده از <code dir="ltr">json-server</code> شبیه‌سازی شده‌اند و صرفا جهت پرزنت می‌باشند.</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
