import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type ThemeName = 'nikan-light' | 'nikan-dark'

interface ThemeState {
  theme: ThemeName
  setTheme: (t: ThemeName) => void
  toggle: () => void
}

const apply = (t: ThemeName) => document.documentElement.setAttribute('data-theme', t)

export const useThemeStore = create<ThemeState>()(
  persist(
    (set, get) => ({
      theme: document.documentElement.getAttribute('data-theme') === 'nikan-dark' ? 'nikan-dark' : 'nikan-light',
      setTheme: (theme) => {
        apply(theme)
        set({ theme })
      },
      toggle: () => get().setTheme(get().theme === 'nikan-light' ? 'nikan-dark' : 'nikan-light'),
    }),
    {
      name: 'nikan-theme',
      onRehydrateStorage: () => (state) => state && apply(state.theme),
    },
  ),
)
