import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { http } from '../services/api'
import type { User } from '../types'

interface AuthState {
  user: Omit<User, 'password'> | null
  login: (email: string, password: string) => Promise<{ ok: true } | { ok: false; error: string }>
  logout: () => void
  updateProfile: (patch: Partial<Pick<User, 'name' | 'title' | 'phone' | 'email'>>) => void
}

/**
 * Mock authentication: looks the user up in json-server and compares the
 * password client-side. Obviously not secure – fine for a front-end demo.
 */
export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      async login(email, password) {
        try {
          const { data } = await http.get<User[]>('/users', { params: { email: email.trim().toLowerCase() } })
          await new Promise((r) => setTimeout(r, 700)) // feel like a real request
          const found = data.find((u) => u.password === password)
          if (!found) return { ok: false, error: 'ایمیل یا گذرواژه نادرست است' }
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          const { password: _pw, ...safe } = found
          set({ user: safe })
          return { ok: true }
        } catch {
          return { ok: false, error: 'ارتباط با سرور داده برقرار نشد. (npm run dev را اجرا کنید)' }
        }
      },
      logout: () => set({ user: null }),
      updateProfile: (patch) => {
        const u = get().user
        if (u) set({ user: { ...u, ...patch } })
      },
    }),
    { name: 'nikan-auth' },
  ),
)
