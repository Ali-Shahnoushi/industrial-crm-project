/** Locale-aware formatting helpers: Persian digits, Toman, Jalali dates. */

const nf = new Intl.NumberFormat('fa-IR')
const PERSIAN_DIGITS = '۰۱۲۳۴۵۶۷۸۹'

export const cx = (...parts: (string | false | null | undefined)[]) => parts.filter(Boolean).join(' ')

export const digits = (v: string | number) => String(v).replace(/\d/g, (d) => PERSIAN_DIGITS[+d])
export const num = (n: number) => nf.format(n)
export const toman = (n: number) => `${nf.format(Math.round(n))} تومان`

/** 1_250_000_000 → "۱٫۲۵ میلیارد" */
export function compact(n: number): string {
  const abs = Math.abs(n)
  const f = (v: number) => nf.format(Math.round(v * 10) / 10)
  if (abs >= 1e12) return `${f(n / 1e12)} هزار میلیارد`
  if (abs >= 1e9) return `${f(n / 1e9)} میلیارد`
  if (abs >= 1e6) return `${f(n / 1e6)} میلیون`
  if (abs >= 1e3) return `${f(n / 1e3)} هزار`
  return nf.format(n)
}
export const compactToman = (n: number) => `${compact(n)} تومان`

export function phoneFa(p: string): string {
  return digits(p.replace(/^(\d{4})(\d{3})(\d{4})$/, '$1 $2 $3'))
}

const dateLong = new Intl.DateTimeFormat('fa-IR-u-ca-persian', { year: 'numeric', month: 'long', day: 'numeric' })
const dateNum = new Intl.DateTimeFormat('fa-IR-u-ca-persian', { year: 'numeric', month: '2-digit', day: '2-digit' })
const timeFmt = new Intl.DateTimeFormat('fa-IR', { hour: '2-digit', minute: '2-digit' })
const weekdayFmt = new Intl.DateTimeFormat('fa-IR-u-ca-persian', { weekday: 'long' })

export const dateFa = (iso: string | Date) => dateLong.format(new Date(iso))
export const dateShort = (iso: string | Date) => dateNum.format(new Date(iso))
export const timeFa = (iso: string | Date) => timeFmt.format(new Date(iso))
export const dateTimeFa = (iso: string | Date) => `${dateShort(iso)} - ${timeFa(iso)}`
export const weekdayFa = (iso: string | Date) => weekdayFmt.format(new Date(iso))

export function relativeFa(iso: string | Date, now = Date.now()): string {
  const diff = now - new Date(iso).getTime()
  const future = diff < 0
  const s = Math.abs(diff) / 1000
  const suffix = future ? 'دیگر' : 'پیش'
  if (s < 60) return 'همین الان'
  const m = Math.floor(s / 60)
  if (m < 60) return `${num(m)} دقیقه ${suffix}`
  const h = Math.floor(m / 60)
  if (h < 24) return `${num(h)} ساعت ${suffix}`
  const d = Math.floor(h / 24)
  if (d < 30) return `${num(d)} روز ${suffix}`
  const mo = Math.floor(d / 30)
  if (mo < 12) return `${num(mo)} ماه ${suffix}`
  return `${num(Math.floor(mo / 12))} سال ${suffix}`
}

export const fullName = (c: { firstName: string; lastName: string }) => `${c.firstName} ${c.lastName}`

/** Stable pseudo-random hue from a string, used for avatar colours. */
export function hueFrom(str: string): number {
  let h = 0
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) % 360
  return h
}
