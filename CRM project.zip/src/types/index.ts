export type Role = 'admin' | 'manager' | 'sales' | 'support' | 'warehouse' | 'finance' | 'marketing'
export type Presence = 'online' | 'away' | 'offline'

export interface User {
  id: string
  name: string
  email: string
  password?: string
  title: string
  role: Role
  presence: Presence
  phone: string
  joinedAt: string
}

export type CustomerStatus = 'active' | 'vip' | 'new' | 'inactive'
export interface Customer {
  id: string
  firstName: string
  lastName: string
  type: 'individual' | 'company'
  company: string
  email: string
  phone: string
  city: string
  address: string
  status: CustomerStatus
  source: string
  tags: string[]
  assignedTo: string
  notes: string
  createdAt: string
  lastContact: string
  lastPurchase?: string
  totalSpent: number
  ordersCount: number
}

export type LeadStage = 'new' | 'contacted' | 'proposal' | 'negotiation' | 'won' | 'lost'
export interface Lead {
  id: string
  title: string
  contactName: string
  company: string
  phone: string
  value: number
  stage: LeadStage
  probability: number
  source: string
  assignedTo: string
  expectedClose: string
  createdAt: string
  order: number
}

export interface Product {
  id: string
  sku: string
  name: string
  category: string
  price: number
  cost: number
  stock: number
  minStock: number
  unit: string
  warehouse: string
  supplier: string
  createdAt: string
}

export interface StockMovement {
  id: string
  productId: string
  type: 'in' | 'out' | 'adjust'
  quantity: number
  date: string
  userId: string
  note: string
}

export type InvoiceStatus = 'paid' | 'pending' | 'overdue' | 'cancelled'
export interface SaleItem {
  productId: string
  name: string
  quantity: number
  price: number
}
export interface Sale {
  id: string
  number: string
  date: string
  customerId: string
  userId: string
  status: InvoiceStatus
  paymentMethod: string
  items: SaleItem[]
  discount: number
  total: number
}

export type ActivityType = 'call' | 'meeting' | 'email' | 'note'
export interface Activity {
  id: string
  customerId: string
  type: ActivityType
  title: string
  description: string
  date: string
  userId: string
}

export type TaskStatus = 'todo' | 'in-progress' | 'done'
export type Priority = 'low' | 'medium' | 'high'
export interface Task {
  id: string
  title: string
  description: string
  status: TaskStatus
  priority: Priority
  dueDate: string
  assignedTo: string
  customerId: string | null
  createdAt: string
}

export type EventType = 'meeting' | 'call' | 'deadline' | 'reminder'
export interface CalendarEvent {
  id: string
  title: string
  type: EventType
  start: string
  end: string
  customerId: string | null
  userId: string
  location: string
}

export type TicketStatus = 'open' | 'pending' | 'resolved' | 'closed'
export interface TicketMessage {
  from: 'customer' | 'agent'
  text: string
  date: string
}
export interface Ticket {
  id: string
  number: string
  subject: string
  category: string
  customerId: string
  priority: Priority
  status: TicketStatus
  assignedTo: string
  createdAt: string
  messages: TicketMessage[]
}

export interface ChatRoom {
  id: string
  name: string
  type: 'dm' | 'group'
  members: string[]
  unread: number
}
export interface ChatMessage {
  id: string
  roomId: string
  senderId: string
  text: string
  date: string
}

export interface AppNotification {
  id: string
  userId: string
  type: 'lead' | 'stock' | 'invoice' | 'ticket' | 'task' | 'system'
  title: string
  description: string
  link: string
  read: boolean
  date: string
}

/** Maps json-server resource names to their record types. */
export interface Resources {
  users: User
  customers: Customer
  leads: Lead
  products: Product
  stockMovements: StockMovement
  sales: Sale
  activities: Activity
  tasks: Task
  events: CalendarEvent
  tickets: Ticket
  rooms: ChatRoom
  messages: ChatMessage
  notifications: AppNotification
}
export type ResourceName = keyof Resources
