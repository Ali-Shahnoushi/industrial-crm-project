import { useState } from 'react'
import { CalendarDays, ChevronLeft, ChevronRight, X } from 'lucide-react'
import { dateFa, digits } from '../../utils/format'
import { JALALI_MONTHS, WEEKDAYS_SHORT, fromJ, isSameDay, monthGrid, shiftMonth, toJ } from '../../utils/jalali'
import { cx } from '../../utils/format'

interface Props {
  value: string | null | undefined
  onChange: (iso: string | null) => void
  placeholder?: string
  clearable?: boolean
}

/** Jalali date picker. The calendar expands inline so it never gets clipped inside modals. */
export function DatePicker({ value, onChange, placeholder = 'انتخاب تاریخ', clearable }: Props) {
  const selected = value ? new Date(value) : null
  const base = toJ(selected ?? new Date())
  const [open, setOpen] = useState(false)
  const [view, setView] = useState({ jy: base.jy, jm: base.jm })
  const today = new Date()

  const cells = monthGrid(view.jy, view.jm)
  const move = (d: number) => setView((v) => shiftMonth(v.jy, v.jm, d))

  return (
    <div className="w-full">
      <div className="relative">
        <button
          type="button"
          className="input w-full justify-start gap-2 text-start"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
        >
          <CalendarDays className="size-4 text-base-content/50" />
          <span className={cx(!selected && 'text-base-content/40')}>{selected ? dateFa(selected) : placeholder}</span>
        </button>
        {clearable && selected && (
          <button type="button" className="btn btn-ghost btn-xs btn-circle absolute end-2 top-1/2 -translate-y-1/2" onClick={() => onChange(null)} aria-label="پاک کردن">
            <X className="size-3" />
          </button>
        )}
      </div>

      {open && (
        <div className="mt-2 rounded-2xl border border-base-300 bg-base-100 p-3 shadow-sm">
          <div className="mb-2 flex items-center justify-between">
            <button type="button" className="btn btn-ghost btn-sm btn-circle" onClick={() => move(-1)} aria-label="ماه قبل">
              <ChevronRight className="size-4" />
            </button>
            <span className="text-sm font-bold">{JALALI_MONTHS[view.jm - 1]} {digits(view.jy)}</span>
            <button type="button" className="btn btn-ghost btn-sm btn-circle" onClick={() => move(1)} aria-label="ماه بعد">
              <ChevronLeft className="size-4" />
            </button>
          </div>
          <div className="grid grid-cols-7 gap-1 text-center text-xs">
            {WEEKDAYS_SHORT.map((w) => (
              <span key={w} className="py-1 text-base-content/50">{w}</span>
            ))}
            {cells.map((jd, i) => {
              if (!jd) return <span key={i} />
              const date = fromJ(view.jy, view.jm, jd, 12)
              const isSel = selected && isSameDay(date, selected)
              return (
                <button
                  type="button"
                  key={i}
                  onClick={() => {
                    // keep time-of-day of existing value, else noon
                    const d = fromJ(view.jy, view.jm, jd, selected?.getHours() ?? 12, selected?.getMinutes() ?? 0)
                    onChange(d.toISOString())
                    setOpen(false)
                  }}
                  className={cx(
                    'aspect-square rounded-lg text-sm transition-colors hover:bg-primary/10',
                    isSel && 'bg-primary font-bold text-primary-content hover:bg-primary',
                    !isSel && isSameDay(date, today) && 'ring-1 ring-primary text-primary',
                  )}
                >
                  {digits(jd)}
                </button>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
