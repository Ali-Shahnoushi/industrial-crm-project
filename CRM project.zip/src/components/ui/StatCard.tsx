import type { LucideIcon } from 'lucide-react'
import { ArrowDownLeft, ArrowUpRight } from 'lucide-react'
import { cx, digits } from '../../utils/format'

const tones = {
  primary: 'bg-primary/10 text-primary',
  secondary: 'bg-secondary/15 text-secondary',
  success: 'bg-success/15 text-success',
  warning: 'bg-warning/20 text-warning',
  error: 'bg-error/10 text-error',
  info: 'bg-info/15 text-info',
} as const

interface Props {
  title: string
  value: string
  icon: LucideIcon
  tone?: keyof typeof tones
  /** Percent change vs previous period (positive = good). */
  delta?: number
  hint?: string
  loading?: boolean
}

export function StatCard({ title, value, icon: Icon, tone = 'primary', delta, hint, loading }: Props) {
  return (
    <div className="card-surface p-5 transition-shadow hover:shadow-md">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm text-base-content/60">{title}</p>
          {loading ? (
            <div className="skeleton mt-2 h-8 w-28" />
          ) : (
            <p className="mt-1 truncate text-2xl font-extrabold tracking-tight">{value}</p>
          )}
        </div>
        <span className={cx('flex size-11 shrink-0 items-center justify-center rounded-xl', tones[tone])}>
          <Icon className="size-5" />
        </span>
      </div>
      {(delta !== undefined || hint) && !loading && (
        <div className="mt-3 flex items-center gap-2 text-xs">
          {delta !== undefined && (
            <span
              className={cx(
                'inline-flex items-center gap-0.5 rounded-full px-2 py-0.5 font-semibold',
                delta >= 0 ? 'bg-success/15 text-success' : 'bg-error/10 text-error',
              )}
            >
              {delta >= 0 ? <ArrowUpRight className="size-3.5" /> : <ArrowDownLeft className="size-3.5" />}
              {digits(Math.abs(delta).toFixed(1))}٪
            </span>
          )}
          {hint && <span className="text-base-content/50">{hint}</span>}
        </div>
      )}
    </div>
  )
}
