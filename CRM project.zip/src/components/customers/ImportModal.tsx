import { useRef, useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import toast from 'react-hot-toast'
import { CheckCircle2, Download, FileSpreadsheet, Sparkles, Upload, XCircle } from 'lucide-react'
import { Modal } from '../ui/Modal'
import { createOne } from '../../services/api'
import { downloadCsv, parseCsv, toLatinDigits } from '../../utils/csv'
import { customerStatus } from '../../utils/meta'
import { cx, num } from '../../utils/format'
import type { Customer, CustomerStatus } from '../../types'

type Row = { ok: boolean; reason?: string; data: Omit<Customer, 'id'> }

const alias = {
  firstName: ['نام', 'firstname', 'first_name', 'first name'],
  lastName: ['نام خانوادگی', 'lastname', 'last_name', 'last name'],
  company: ['شرکت', 'نام شرکت', 'company'],
  email: ['ایمیل', 'email'],
  phone: ['موبایل', 'تلفن', 'شماره تماس', 'phone', 'mobile'],
  city: ['شهر', 'city'],
  status: ['وضعیت', 'status'],
} as const

const pickField = (row: Record<string, string>, keys: readonly string[]) => {
  for (const [h, v] of Object.entries(row)) if (keys.includes(h.trim().toLowerCase())) return (v ?? '').trim()
  return ''
}
const statusFromText = (t: string): CustomerStatus => {
  const hit = (Object.keys(customerStatus) as CustomerStatus[]).find((k) => customerStatus[k].label === t || k === t.toLowerCase())
  return hit ?? 'new'
}

function toRow(raw: Record<string, string>): Row {
  const firstName = pickField(raw, alias.firstName)
  const lastName = pickField(raw, alias.lastName)
  const email = pickField(raw, alias.email).toLowerCase()
  const phone = toLatinDigits(pickField(raw, alias.phone)).replace(/\s|-/g, '')
  const company = pickField(raw, alias.company)
  const now = new Date().toISOString()
  const data: Row['data'] = {
    firstName, lastName, company, email, phone,
    type: company ? 'company' : 'individual',
    city: pickField(raw, alias.city) || 'تهران',
    address: '',
    status: statusFromText(pickField(raw, alias.status)),
    source: 'ایمپورت فایل',
    tags: [],
    assignedTo: 'u-3',
    notes: '',
    createdAt: now,
    lastContact: now,
    totalSpent: 0,
    ordersCount: 0,
  }
  if (!firstName || !lastName) return { ok: false, reason: 'نام یا نام خانوادگی خالی است', data }
  if (!/^09\d{9}$/.test(phone)) return { ok: false, reason: 'شماره موبایل نامعتبر', data }
  if (!/^\S+@\S+\.\S+$/.test(email)) return { ok: false, reason: 'ایمیل نامعتبر', data }
  return { ok: true, data }
}

const SAMPLE = [
  { نام: 'کیوان', 'نام خانوادگی': 'صالحی', شرکت: 'شرکت آرمان‌نت', ایمیل: 'keyvan@armannet.ir', موبایل: '09121112233', شهر: 'تهران', وضعیت: 'جدید' },
  { نام: 'مهسا', 'نام خانوادگی': 'نیک‌نام', شرکت: '', ایمیل: 'mahsa.nik@gmail.com', موبایل: '09351234567', شهر: 'اصفهان', وضعیت: 'فعال' },
  { نام: 'داریوش', 'نام خانوادگی': 'فتحی', شرکت: 'گروه تجاری فتحی', ایمیل: 'd.fathi@fathigroup.ir', موبایل: '09191239876', شهر: 'شیراز', وضعیت: 'ویژه' },
  { نام: 'ناهید', 'نام خانوادگی': 'ملکی', شرکت: '', ایمیل: 'nahid-maleki', موبایل: '0912', شهر: 'مشهد', وضعیت: 'جدید' },
]

export function ImportModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [rows, setRows] = useState<Row[]>([])
  const [fileName, setFileName] = useState('')
  const [busy, setBusy] = useState(false)
  const [drag, setDrag] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const qc = useQueryClient()

  const reset = () => { setRows([]); setFileName('') }
  const close = () => { reset(); onClose() }
  const valid = rows.filter((r) => r.ok)

  const load = async (file: File) => {
    if (!/\.csv$/i.test(file.name)) return toast.error('فقط فایل CSV پشتیبانی می‌شود')
    try {
      const parsed = await parseCsv(file)
      if (!parsed.length) return toast.error('فایل خالی است')
      setFileName(file.name)
      setRows(parsed.map(toRow))
    } catch {
      toast.error('خواندن فایل ناموفق بود')
    }
  }

  const run = async () => {
    setBusy(true)
    try {
      await Promise.all(valid.map((r) => createOne('customers', r.data)))
      await qc.invalidateQueries({ queryKey: ['customers'] })
      toast.success(`${num(valid.length)} مشتری با موفقیت وارد شد`)
      close()
    } catch {
      toast.error('خطا در ایمپورت اطلاعات')
    } finally {
      setBusy(false)
    }
  }

  return (
    <Modal
      open={open}
      onClose={close}
      size="lg"
      title="ایمپورت مشتریان از فایل CSV"
      footer={
        <>
          <button className="btn btn-ghost" onClick={close}>انصراف</button>
          <button className="btn btn-primary" disabled={!valid.length || busy} onClick={run}>
            {busy && <span className="loading loading-spinner loading-xs" />}
            ورود {valid.length ? num(valid.length) : ''} مشتری
          </button>
        </>
      }
    >
      {!rows.length ? (
        <div className="space-y-4">
          <div
            onDragOver={(e) => { e.preventDefault(); setDrag(true) }}
            onDragLeave={() => setDrag(false)}
            onDrop={(e) => { e.preventDefault(); setDrag(false); const f = e.dataTransfer.files[0]; if (f) void load(f) }}
            onClick={() => inputRef.current?.click()}
            className={cx(
              'flex cursor-pointer flex-col items-center gap-3 rounded-2xl border-2 border-dashed px-6 py-12 text-center transition-colors',
              drag ? 'border-primary bg-primary/10' : 'border-base-300 hover:border-primary/60 hover:bg-base-200/50',
            )}
          >
            <span className="flex size-14 items-center justify-center rounded-2xl bg-primary/10 text-primary"><Upload className="size-7" /></span>
            <p className="font-semibold">فایل CSV را اینجا بکشید یا کلیک کنید</p>
            <p className="text-sm text-base-content/60">ستون‌ها: نام، نام خانوادگی، شرکت، ایمیل، موبایل، شهر، وضعیت</p>
            <input ref={inputRef} type="file" accept=".csv,text/csv" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) void load(f); e.target.value = '' }} />
          </div>
          <div className="flex flex-wrap gap-2">
            <button className="btn btn-sm" onClick={() => downloadCsv('nikan-customers-template.csv', SAMPLE.slice(0, 2))}>
              <Download className="size-4" /> دانلود فایل نمونه
            </button>
            <button className="btn btn-sm btn-primary btn-soft" onClick={() => { setFileName('داده نمونه'); setRows(SAMPLE.map(toRow)) }}>
              <Sparkles className="size-4" /> بارگذاری داده نمونه (برای دمو)
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-3 text-sm">
            <span className="flex items-center gap-1.5 font-semibold"><FileSpreadsheet className="size-4 text-primary" /> {fileName}</span>
            <span className="badge badge-success badge-soft">{num(valid.length)} معتبر</span>
            {rows.length - valid.length > 0 && <span className="badge badge-error badge-soft">{num(rows.length - valid.length)} نامعتبر</span>}
            <button className="btn btn-ghost btn-xs ms-auto" onClick={reset}>انتخاب فایل دیگر</button>
          </div>
          <div className="max-h-72 overflow-auto rounded-xl border border-base-300">
            <table className="table table-sm">
              <thead className="sticky top-0 bg-base-200"><tr><th /><th>نام</th><th>شرکت</th><th>ایمیل</th><th>موبایل</th><th>شهر</th></tr></thead>
              <tbody>
                {rows.slice(0, 50).map((r, i) => (
                  <tr key={i} className={cx(!r.ok && 'bg-error/5')}>
                    <td>{r.ok ? <CheckCircle2 className="size-4 text-success" /> : <span title={r.reason}><XCircle className="size-4 text-error" /></span>}</td>
                    <td>{r.data.firstName} {r.data.lastName}</td>
                    <td>{r.data.company || '—'}</td>
                    <td className="ltr-text">{r.data.email}</td>
                    <td className="ltr-text">{r.data.phone}</td>
                    <td>{r.ok ? r.data.city : <span className="text-xs text-error">{r.reason}</span>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </Modal>
  )
}
