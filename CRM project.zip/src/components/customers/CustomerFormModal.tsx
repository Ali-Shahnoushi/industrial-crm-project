import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Modal } from '../ui/Modal'
import { Field } from '../ui/Field'
import { useCreate, useList, useUpdate } from '../../hooks/useData'
import { CITIES, SOURCES, customerStatus } from '../../utils/meta'
import { toLatinDigits } from '../../utils/csv'
import { cx } from '../../utils/format'
import type { Customer, CustomerStatus } from '../../types'

const TAGS = ['وفادار', 'عمده‌فروش', 'خرده‌فروش', 'سازمانی', 'نیازمند پیگیری', 'تخفیف‌دار', 'پرمشتری']

const schema = z
  .object({
    type: z.enum(['individual', 'company']),
    firstName: z.string().trim().min(2, 'نام را وارد کنید'),
    lastName: z.string().trim().min(2, 'نام خانوادگی را وارد کنید'),
    company: z.string().trim(),
    email: z.email('ایمیل معتبر نیست'),
    phone: z.string().refine((v) => /^09\d{9}$/.test(toLatinDigits(v.trim())), 'شماره موبایل معتبر نیست (مثال: ۰۹۱۲۳۴۵۶۷۸۹)'),
    city: z.string().min(1, 'شهر را انتخاب کنید'),
    address: z.string().trim(),
    status: z.enum(['active', 'vip', 'new', 'inactive']),
    source: z.string().min(1),
    assignedTo: z.string().min(1, 'کارشناس را انتخاب کنید'),
    tags: z.array(z.string()),
    notes: z.string().trim(),
  })
  .refine((d) => d.type === 'individual' || d.company.length >= 2, { path: ['company'], message: 'نام شرکت را وارد کنید' })

type Values = z.infer<typeof schema>
const FORM_ID = 'customer-form'

function CustomerForm({ customer, onSubmit }: { customer?: Customer; onSubmit: (v: Values) => void }) {
  const { data: users } = useList('users')
  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<Values>({
    resolver: zodResolver(schema),
    defaultValues: {
      type: customer?.type ?? 'individual',
      firstName: customer?.firstName ?? '',
      lastName: customer?.lastName ?? '',
      company: customer?.company ?? '',
      email: customer?.email ?? '',
      phone: customer?.phone ?? '',
      city: customer?.city ?? 'تهران',
      address: customer?.address ?? '',
      status: customer?.status ?? 'new',
      source: customer?.source ?? SOURCES[0],
      assignedTo: customer?.assignedTo ?? 'u-3',
      tags: customer?.tags ?? [],
      notes: customer?.notes ?? '',
    },
  })
  const type = watch('type')
  const tags = watch('tags')
  const toggleTag = (t: string) => setValue('tags', tags.includes(t) ? tags.filter((x) => x !== t) : [...tags, t])

  return (
    <form id={FORM_ID} onSubmit={handleSubmit(onSubmit)} noValidate className="grid grid-cols-1 gap-x-4 gap-y-1 sm:grid-cols-2">
      <div className="sm:col-span-2">
        <div role="tablist" className="tabs tabs-box w-fit">
          {(['individual', 'company'] as const).map((t) => (
            <label key={t} role="tab" className={cx('tab', type === t && 'tab-active')}>
              <input type="radio" value={t} className="hidden" {...register('type')} />
              {t === 'individual' ? 'حقیقی' : 'حقوقی (شرکت)'}
            </label>
          ))}
        </div>
      </div>

      <Field label="نام" required error={errors.firstName?.message}>
        <input className="input w-full" {...register('firstName')} />
      </Field>
      <Field label="نام خانوادگی" required error={errors.lastName?.message}>
        <input className="input w-full" {...register('lastName')} />
      </Field>
      {type === 'company' && (
        <Field label="نام شرکت" required error={errors.company?.message} className="sm:col-span-2">
          <input className="input w-full" {...register('company')} />
        </Field>
      )}
      <Field label="ایمیل" required error={errors.email?.message}>
        <input type="email" dir="ltr" className="input w-full text-start" {...register('email')} />
      </Field>
      <Field label="شماره موبایل" required error={errors.phone?.message}>
        <input dir="ltr" inputMode="numeric" placeholder="09123456789" className="input w-full text-start" {...register('phone')} />
      </Field>
      <Field label="شهر" required error={errors.city?.message}>
        <select className="select w-full" {...register('city')}>
          {CITIES.map((c) => <option key={c}>{c}</option>)}
        </select>
      </Field>
      <Field label="وضعیت">
        <select className="select w-full" {...register('status')}>
          {(Object.keys(customerStatus) as CustomerStatus[]).map((s) => <option key={s} value={s}>{customerStatus[s].label}</option>)}
        </select>
      </Field>
      <Field label="منبع جذب">
        <select className="select w-full" {...register('source')}>
          {SOURCES.map((s) => <option key={s}>{s}</option>)}
        </select>
      </Field>
      <Field label="کارشناس مسئول" required error={errors.assignedTo?.message}>
        <select className="select w-full" {...register('assignedTo')}>
          {users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
        </select>
      </Field>
      <Field label="آدرس" className="sm:col-span-2">
        <input className="input w-full" {...register('address')} />
      </Field>
      <div className="sm:col-span-2">
        <p className="fieldset-legend mb-1 text-sm font-medium">برچسب‌ها</p>
        <div className="flex flex-wrap gap-2">
          {TAGS.map((t) => (
            <button key={t} type="button" onClick={() => toggleTag(t)} className={cx('badge badge-lg cursor-pointer', tags.includes(t) ? 'badge-primary' : 'badge-outline')}>
              {t}
            </button>
          ))}
        </div>
      </div>
      <Field label="یادداشت" className="sm:col-span-2">
        <textarea rows={3} className="textarea w-full" {...register('notes')} />
      </Field>
    </form>
  )
}

export function CustomerFormModal({ open, onClose, customer }: { open: boolean; onClose: () => void; customer?: Customer }) {
  const create = useCreate('customers', { success: 'مشتری جدید با موفقیت افزوده شد' })
  const update = useUpdate('customers', { success: 'اطلاعات مشتری بروزرسانی شد' })
  const busy = create.isPending || update.isPending

  const submit = (v: Values) => {
    const payload = { ...v, phone: toLatinDigits(v.phone.trim()), email: v.email.trim().toLowerCase(), company: v.type === 'company' ? v.company : '' }
    if (customer) update.mutate({ id: customer.id, ...payload }, { onSuccess: onClose })
    else {
      const now = new Date().toISOString()
      create.mutate({ ...payload, createdAt: now, lastContact: now, totalSpent: 0, ordersCount: 0 }, { onSuccess: onClose })
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      size="lg"
      title={customer ? 'ویرایش مشتری' : 'افزودن مشتری جدید'}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose}>انصراف</button>
          <button type="submit" form={FORM_ID} className="btn btn-primary" disabled={busy}>
            {busy && <span className="loading loading-spinner loading-xs" />}
            {customer ? 'ذخیره تغییرات' : 'افزودن مشتری'}
          </button>
        </>
      }
    >
      <CustomerForm customer={customer} onSubmit={submit} />
    </Modal>
  )
}
